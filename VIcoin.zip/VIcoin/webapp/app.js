
let balance = 0;

document.getElementById('tap-btn').addEventListener('click', () => {
    balance += 1;
    document.getElementById('balance').textContent = `${balance} VIC`;
});
