
BOT_TOKEN = "твой_токен_от_BotFather"
WEB_APP_URL = "https://your-web-app-url.com"
