
from aiogram import Bot, Dispatcher, types, executor
from config import BOT_TOKEN, WEB_APP_URL

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    keyboard = types.InlineKeyboardMarkup()
    web_app = types.WebAppInfo(url=WEB_APP_URL)
    keyboard.add(types.InlineKeyboardButton("🚀 Запустить VIcoin", web_app=web_app))
    await message.answer("Добро пожаловать в VIcoin🤍!", reply_markup=keyboard)

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
